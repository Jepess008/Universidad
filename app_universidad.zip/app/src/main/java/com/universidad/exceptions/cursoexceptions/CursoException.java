package com.universidad.exceptions.cursoexceptions;

public class CursoException extends Exception {
    public CursoException(String mensaje){
        super(mensaje);
    }
}
