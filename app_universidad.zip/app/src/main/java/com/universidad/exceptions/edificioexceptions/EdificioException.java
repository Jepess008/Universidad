package com.universidad.exceptions.edificioexceptions;

public class EdificioException extends Exception {
    public EdificioException(String mensaje){
        super(mensaje);
    }
}
