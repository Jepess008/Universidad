package com.universidad.exceptions.departamentoexceptions;

public class DepartamentoNullException extends Exception {
    
    public DepartamentoNullException(String mensaje){
        super(mensaje);
    }
}
