package com.universidad.exceptions.estudianteexceptions;

public class EstudianteException extends Exception   {
    public EstudianteException(String mensaje){
        super(mensaje);
    }
}
