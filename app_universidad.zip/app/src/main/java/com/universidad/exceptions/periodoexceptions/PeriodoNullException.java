package com.universidad.exceptions.periodoexceptions;

public class PeriodoNullException extends Exception {
    public PeriodoNullException(String mensaje){
        super(mensaje);
    }
    
}
