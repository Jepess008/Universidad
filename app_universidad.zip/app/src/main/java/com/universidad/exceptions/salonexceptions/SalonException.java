package com.universidad.exceptions.salonexceptions;

public class SalonException extends Exception {
    public SalonException(String mensaje){
        super(mensaje);
    }
}
