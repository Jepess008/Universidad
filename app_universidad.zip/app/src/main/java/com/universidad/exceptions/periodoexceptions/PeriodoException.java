package com.universidad.exceptions.periodoexceptions;

public class PeriodoException extends Exception {
    public PeriodoException(String mensaje){
        super(mensaje);
    }
}

