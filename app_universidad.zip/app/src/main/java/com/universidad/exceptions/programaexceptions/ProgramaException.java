package com.universidad.exceptions.programaexceptions;

public class ProgramaException extends Exception {
    public ProgramaException(String mensaje){
        super(mensaje);
    }
}
