package com.universidad.exceptions.horarioexceptions;

public class HorarioException extends Exception {
    public HorarioException(String mensaje){
        super(mensaje);
    }
}
