package com.universidad.exceptions.tarifaexceptions;

public class TarifaException extends Exception {
    public TarifaException(String mensaje){
        super(mensaje);
    }
}
