package com.universidad.exceptions.programaexceptions;

public class ProgramaNullException extends Exception {
    public ProgramaNullException(String mensaje){
        super(mensaje);
    }
}
