package com.universidad.exceptions.departamentoexceptions;

public class DepartamentoExceptions extends Exception{
    public DepartamentoExceptions(String mensaje){
        super(mensaje);
    }
}
