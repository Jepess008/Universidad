package com.universidad.exceptions.cursoexceptions;

public class CursoNullException extends Exception {
    public CursoNullException(String mensaje){
        super(mensaje);
    }
}
