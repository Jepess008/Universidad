package com.universidad.exceptions.salonexceptions;

public class SalonNullException extends Exception {
    public SalonNullException(String mensaje){
        super(mensaje);
    }
}
