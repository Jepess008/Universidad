package com.universidad.exceptions.docenteexceptions;

public class DocenteNullException extends Exception {
    public DocenteNullException(String mensaje){
        super(mensaje);
    }
    
}
