package com.universidad.exceptions.tarifaexceptions;

public class TarifaNullException extends Exception {
    public TarifaNullException(String mensaje){
        super(mensaje);
    }
}
