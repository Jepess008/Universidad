package com.universidad.exceptions.asignaturaexceptions;

public class AsignaturaNullException extends Exception {
    public AsignaturaNullException(String mensaje){
        super(mensaje);
    }
}
