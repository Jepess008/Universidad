package com.universidad.exceptions.estudianteexceptions;

public class EstudianteNullException extends Exception {

    public EstudianteNullException(String mensaje){
        super(mensaje);
    }
    
    
}
