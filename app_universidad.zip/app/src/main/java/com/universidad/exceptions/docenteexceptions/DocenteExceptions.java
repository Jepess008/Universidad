package com.universidad.exceptions.docenteexceptions;

public class DocenteExceptions extends Exception  {
    public DocenteExceptions(String mensaje){
        super(mensaje);
    }
}
