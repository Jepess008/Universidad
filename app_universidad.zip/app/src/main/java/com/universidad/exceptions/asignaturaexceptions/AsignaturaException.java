package com.universidad.exceptions.asignaturaexceptions;

public class AsignaturaException extends Exception {
    public AsignaturaException(String mensaje){
        super(mensaje);
    }
}
