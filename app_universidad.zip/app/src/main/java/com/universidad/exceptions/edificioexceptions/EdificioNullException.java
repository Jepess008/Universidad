package com.universidad.exceptions.edificioexceptions;

public class EdificioNullException extends Exception {
    public EdificioNullException(String mensaje){
        super(mensaje);
    }
}
